import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;

public class Player {
	private static final int[] SHIP_LENGTHS = {2, 3, 3, 4, 5};
	private static final int NUM_SHIPS = 5;
	private static final int HORIZONTAL = 0;
	private static final int VERTICAL = 1;
	private static final char EMPTY_CELL = '~';

	private Grid myGrid;
	private Grid oppGrid;
	private Scanner reader;

	private List<Coordinate> hitCoordinates;

	private int shipHits = 0;


	public Player(Scanner reader) {
		myGrid = new Grid();
		oppGrid = new Grid();
		this.hitCoordinates = new ArrayList<>();
		this.reader = reader;

	}

	public void promptAndPlaceShips() {
		for (int i = 0; i < NUM_SHIPS; i++) {
			System.out.println("Your current grid of ships:");
			printMyShips();
			System.out.println();

			System.out.println("Now you need to place a ship of length " + SHIP_LENGTHS[i] + ".");

			int shipRow = 0;
			int shipColumn = 0;
			int shipDirection = 0;

			boolean isValidInput = false;
			do {
				System.out.print("Which row? (1-10) ");
				String rowInput = reader.nextLine();
				if (!isValidInput(rowInput)) {
					System.out.println("Invalid input. Please enter a number.");
					continue;
				}
				shipRow = Integer.parseInt(rowInput) - 1;
				isValidInput = true;
			} while (!isValidInput);

			isValidInput = false;
			do {
				System.out.print("Which column? (1-10) ");
				String columnInput = reader.nextLine();
				if (!isValidInput(columnInput)) {
					System.out.println("Invalid input. Please enter a number.");
					continue;
				}
				shipColumn = Integer.parseInt(columnInput) - 1;
				isValidInput = true;
			} while (!isValidInput);

			isValidInput = false;
			do {
				System.out.print("Which direction? (0 - horizontal, 1 - vertical) ");
				String directionInput = reader.nextLine();
				if (!isValidInput(directionInput)) {
					System.out.println("Invalid input. Please enter a number.");
					continue;
				}
				shipDirection = Integer.parseInt(directionInput);
				isValidInput = true;
			} while (!isValidInput);

			if (!isValidPlacement(shipRow, shipColumn, shipDirection, SHIP_LENGTHS[i])) {
				System.out.println("Invalid ship placement. Please try again.");
				i--; // Retry placing the same ship
				continue;
			}else {
				placeShip(shipRow, shipColumn, shipDirection, SHIP_LENGTHS[i]);
			}


		}

		// Place the fifth ship
		System.out.println("Your current grid of ships:");
		printMyShips();
		System.out.println();


	}






	public int getNumShips() {
		return NUM_SHIPS;
	}

	public void testPlaceShips() {
		placeShip(0, 0, 0, SHIP_LENGTHS[0]);		
		placeShip(1, 1, 0, SHIP_LENGTHS[1]);		
		placeShip(2, 2, 0, SHIP_LENGTHS[2]);		
		placeShip(3, 3, 0, SHIP_LENGTHS[3]);		
		placeShip(4, 4, 0, SHIP_LENGTHS[4]);		
	}

	public int getHits() {
		return shipHits;
	}


	private boolean isValidPlacement(int row, int column, int direction, int shipLength) {
		boolean isValid = true;
		if (!checkIfChar(row) || !checkIfChar(column) || !checkIfChar(direction)) {
			isValid = false;
		}
		if (row < 0 || row > 9 || column < 0 || column > 9) {
			isValid = false; // Invalid row or column
		}

		if (direction != HORIZONTAL && direction != VERTICAL) {
			isValid = false; // Invalid direction
		}

		if ((direction == HORIZONTAL && column + shipLength > 10) || (direction == VERTICAL && row + shipLength > 10)) {
			isValid = false; // Exceeds grid boundaries
		}

		for (int i = 0; i < shipLength; i++) {
			if (direction == HORIZONTAL && (column + i >= 10 || myGrid.hasShip(row, column + i))) {
				isValid = false; // Overlapping ship or out of bounds
			}
			if (direction == VERTICAL && (row + i >= 10 || myGrid.hasShip(row + i, column))) {
				isValid = false; // Overlapping ship or out of bounds
			}
		}

		// Valid placement
		return isValid;
	}



	private  boolean checkIfChar(int input) {
		String input2  = Integer.toString(input);
		try 
		{ 
			Integer.parseInt(input2); 
			return true;
		}  
		catch (NumberFormatException e)  
		{ 
			return false;
		}
	}
	public boolean playerHasWon() {
		if(shipHits == 17) {
			return true;
		}
		return false;
	}

	public void placeShip(int row, int column, int direction, int shipLength) {
		Ship newShip = new Ship(shipLength);
		newShip.setLocation(row, column);
		newShip.setDirection(direction);

		if (direction == HORIZONTAL) {
			for (int i = 0; i < shipLength; i++) {
				Location location = myGrid.get(row, column + i);
				location.setShip(true);
				location.setStatus(EMPTY_CELL);
			}
		} else if (direction == VERTICAL) {
			for (int i = 0; i < shipLength; i++) {
				Location location = myGrid.get(row + i, column);
				location.setShip(true);
				location.setStatus(EMPTY_CELL);
			}
		}
	}

	public void autoPlaceShips() {
		for (int i = 0; i < NUM_SHIPS; i++) {
			int shipRow = -1;
			int shipColumn = -1;
			int shipDirection = -1;

			boolean isValidPlacement = false;
			while (!isValidPlacement) {
				shipRow = Randomizer.nextInt(1, 10) - 1;
				shipColumn = Randomizer.nextInt(1, 10) - 1;
				shipDirection = Randomizer.nextInt(0, 1);

				isValidPlacement = isValidPlacement(shipRow, shipColumn, shipDirection, SHIP_LENGTHS[i]);
				if (isValidPlacement) {
					// Check for overlaps with previously placed ships
					boolean isOverlapping = false;
					if (shipDirection == HORIZONTAL) {
						for (int j = 0; j < SHIP_LENGTHS[i]; j++) {
							if (myGrid.hasShip(shipRow, shipColumn + j)) {
								isOverlapping = true;
								break;
							}
						}
					} else if (shipDirection == VERTICAL) {
						for (int j = 0; j < SHIP_LENGTHS[i]; j++) {
							if (myGrid.hasShip(shipRow + j, shipColumn)) {
								isOverlapping = true;
								break;
							}
						}
					}

					// If there are overlaps, generate a new location and try again
					if (isOverlapping) {
						isValidPlacement = false;
					} else {
						Ship newShip = new Ship(SHIP_LENGTHS[i]);
						newShip.setLocation(shipRow, shipColumn);
						newShip.setDirection(shipDirection);
						placeShip(shipRow, shipColumn, shipDirection, SHIP_LENGTHS[i]);
					}
				}
			}
		}
	}





	public boolean alreadyGuessed(int row, int col){
		return myGrid.alreadyGuessed(row, col);
	}

	public boolean hasShip(int row, int col){
		return myGrid.hasShip(row,col);
	}

	public void printMyShips() {
		myGrid.printShips();
	}

	public Location get(int row, int col){
		return myGrid.get(row,col);
	}

	/*
	public void recordOpponentGuess(int row, int col) {
		if (oppGrid.hasShip(row, col)) {
			oppGrid.markHit(row, col);
		} else {
			oppGrid.markMiss(row, col);
		}
	}
	 */

	public void printMyGuesses() {
		oppGrid.printStatus();
	}
	//computer guesses

	public void computerTurn(Player opponent) {
		Coordinate guess;
		if (hitCoordinates.isEmpty()) {
			guess = getRandomGuess(opponent);
		} else {
			guess = getNeighboringGuess(opponent);
			if (guess == null) {
				guess = getRandomGuess(opponent); // Use random guess if no neighboring guess is available
			}
		}

		int row = guess.getRow();
		int column = guess.getColumn();
		System.out.println("Computer guesses row: " + (row + 1) + " and column: " + (column + 1));

		if (opponent.hasShip(row, column)) {
			if (oppGrid.get(row, column).isUnguessed()) {
				oppGrid.markHit(row, column);
				System.out.println("Computer hit a ship!");
				shipHits++;
				hitCoordinates.add(guess);
			} else {
				System.out.println("Computer already hit this location!");
			}
		} else {
			oppGrid.markMiss(row, column);
			System.out.println("Computer missed");
		}

		System.out.println("Total Hits of Computer: " + shipHits + " out of 17");
	}




	private Coordinate getRandomGuess(Player opponent) {
		List<Coordinate> unguessedPoints = new ArrayList<>();

		for (int row = 0; row < 10; row++) {
			for (int column = 0; column < 10; column++) {
				if (oppGrid.get(row, column).isUnguessed()) {
					unguessedPoints.add(new Coordinate(row, column));
				}
			}
		}

		if (unguessedPoints.isEmpty()) {
			return null;
		}

		int randomIndex = Randomizer.nextInt(unguessedPoints.size());
		return unguessedPoints.get(randomIndex);
	}

	private Coordinate getNeighboringGuess(Player opponent) {
		Coordinate lastHit = hitCoordinates.get(hitCoordinates.size() - 1);
		int lastHitRow = lastHit.getRow();
		int lastHitColumn = lastHit.getColumn();

		List<Coordinate> neighboringPoints = new ArrayList<>();
		addValidPoint(lastHitRow - 1, lastHitColumn, neighboringPoints, opponent); // North
		addValidPoint(lastHitRow + 1, lastHitColumn, neighboringPoints, opponent); // South
		addValidPoint(lastHitRow, lastHitColumn - 1, neighboringPoints, opponent); // West
		addValidPoint(lastHitRow, lastHitColumn + 1, neighboringPoints, opponent); // East

		if (neighboringPoints.isEmpty()) {
			hitCoordinates.remove(lastHit); // Remove the last hit coordinate
			return null;
		}

		int randomIndex = Randomizer.nextInt(neighboringPoints.size());
		return neighboringPoints.get(randomIndex);
	}

	private void addValidPoint(int row, int column, List<Coordinate> neighboringPoints, Player opponent) {
		if (row >= 0 && row < 10 && column >= 0 && column < 10) {
			Coordinate point = new Coordinate(row, column);
			if (!neighboringPoints.contains(point) && oppGrid.get(row, column).isUnguessed()) {
				neighboringPoints.add(point);
			}
		}
	}





	private static class Coordinate {
		private final int row;
		private final int column;

		public Coordinate(int row, int column) {
			this.row = row;
			this.column = column;

		}

		public int getRow() {
			return row;
		}

		public int getColumn() {
			return column;
		}


	}






	public static boolean isValidInput(String input) {
		return !input.isEmpty() && input.matches("\\d+");
	}
	//this is an alternate computerTurn method that just guesses random points in the grid each turn..
	// the code above is in order to guess a neighbor of a previously hit ship the next turn
	/*public void computerTurn(Player opponent) {
    System.out.println("Computer is taking a turn...");

    int row = Randomizer.nextInt(1, 10) - 1;
    int column = Randomizer.nextInt(1, 10) - 1;

    if (opponent.hasShip(row, column)) {
        oppGrid.markHit(row, column);
        System.out.println("Computer hit a ship!");
        shipHits++;
    } else {
        oppGrid.markMiss(row, column);
        System.out.println("Computer missed");
    }

    System.out.println("Total Hits of Computer: " + shipHits + " out of 17");
}
	 */
	public boolean recordHits(Player opponent, int row, int col) {
		boolean shipHit = false;
		if(opponent.hasShip(row, col)){
			if(!oppGrid.get(row,col).checkHit()) {
				oppGrid.markHit(row, col);
				System.out.println("You hit a ship!");
				shipHits++;
				shipHit = true;
			} else {
				System.out.println("You already hit this ship!");
			}
		} else {
			oppGrid.markMiss(row, col);
			System.out.println("You missed");
		}
		System.out.println("Total Hits " + shipHits + " out of 17");
		return shipHit;
	}

}