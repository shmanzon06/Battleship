
public class Location {
	public static final int UNGUESSED = 0;
	public static final int HIT = 1;
	public static final int MISS = 2;

	private boolean hasShip;
	private int status;
	private Ship ship;


	public Location() {
		status = UNGUESSED;
		ship = null;
		hasShip = false;

	}
	public Ship getShip() {
		return ship; // Return the stored ship object
	}

	public boolean checkHit() {
		return status == HIT;
	}

	public boolean checkMiss() {
		return status == MISS;
	}

	public boolean isUnguessed() {
		return status == UNGUESSED;
	}

	public void markHit() {
		status = HIT;

	}


	public void markMiss() {
		status = MISS;
	}

	public boolean hasShip() {
		return hasShip;
	}

	public void setShip(boolean val) {
		hasShip = val;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public int getStatus() {
		return status;
	}

	public boolean isEmpty() {
		return !hasShip && isUnguessed();
	}

}