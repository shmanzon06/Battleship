import java.io.IOException;
import java.util.Scanner;

public class BattleshipTester
// public class Battleship extends ConsoleProgram
{
	/*
	private static int[][] hitLocations;
	private static int[] hitLocationStatus;
	*/

	private static enum guessChoiceOptions {unstarted, down, right, up, left, done};
	public static final int GAME_ITERATIONS = 500;

    public static void main(String[] args) throws IOException {
		System.out.println("===============================");
		System.out.println("Welcome to Battleship Tester.");
		System.out.println("===============================");
    	
        Scanner reader = new Scanner(System.in);

        long start;
        long end;
        double totalTime = 0;
        
		int player1Wins = 0;
		int player2Wins = 0;
		int player1Turns = 0;
		int player2Turns = 0;
		for (int i = 0; i < GAME_ITERATIONS; i++)
		{
			start = System.currentTimeMillis();
			
			Player player1 = new Player(reader);
			player1.autoPlaceShips();

			Player player2 = new Player(reader);
			player2.autoPlaceShips();

			boolean winner1 = false;
	    	boolean winner2 = false;
	    	int turns = 0;
			while (!winner1 && !winner2) {
				turns++;
				player1.computerTurn(player2);
				player2.computerTurn(player1);

				if (player1.playerHasWon()) {
					player1Wins++;
					player1Turns += turns;
					winner1 = true;
					
				}
				if(player2.playerHasWon()){
					player2Wins++;
					player2Turns += turns;
					winner2= true;
				}
				
//				try {
//		          	  Thread.sleep(1000);
//		          	} catch (InterruptedException e) {
//		          	  Thread.currentThread().interrupt();
//		          	}
			}
			
			end = System.currentTimeMillis();
        	totalTime += ((double) (end - start) / 1000);
        	
          

			System.out.println(i);
		}		

		System.out.println();
		System.out.println("player1Wins == " + player1Wins + ", player1Turns/Victory == " + (player1Turns/player1Wins));
		System.out.println("player2Wins == " + player2Wins + ", player2Turns/Victory == " + (player2Turns/player2Wins));
		System.out.println("Average time per game: " + (totalTime / GAME_ITERATIONS) + " seconds");
		System.out.println();

		reader.close();
		System.out.println("Thanks for playing!");
    }
}