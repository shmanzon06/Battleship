import java.util.*;
import java.io.IOException;

public class Battleship
{
	static Scanner reader;

	public static void main(String[] args) throws IOException {
		// Start here! This class should interact with the user
		// to play the game of Battleship

		// You only need to allow for the user to set up each player's
		// ships and for each player to make a guess on the other player's grid
		// Don't worry about finishing the whole game yet.

		// You will probably need to make additions to the Player class to
		// allow for this setting up and guessing

		System.out.println("===============================");
		System.out.println("Welcome to Battleship.");
		System.out.println("===============================");
		System.out.println("First you need to choose the location of your ships");

		Scanner reader = new Scanner(System.in);

		 Player player1 = new Player(reader);
	     player1.promptAndPlaceShips();

	        String inString = "nonnull";

	        inString = "nonnull"; // set up inString again
	        while (!inString.equals("")) {
	            System.out.print("Hit enter for the enemy to choose their ship locations.");
	            inString = reader.nextLine();
	        }


		Player player2 = new Player(reader);
		player2.autoPlaceShips();

		System.out.println("The enemy has placed their ships.");

		// Set up is complete, now play the game.
		inString = "nonnull";        // set up inString again
		while (!inString.equals("")) {
			System.out.print("Hit enter to start guessing.");
			inString = reader.nextLine();
		}
		Player currentPlayer = player1;

		while(!isGameOver(player1,player2)) {


			if (currentPlayer == player1) {
				askForGuess(reader, player1, player2);
				//player1.computerTurn(player2);
				currentPlayer = player2;
			} 
			if(currentPlayer == player2){
				System.out.println("Computer's turn.");
				player2.computerTurn(player1);
				currentPlayer = player1;
			}

		}
		if (player1.playerHasWon()) {
			System.out.println("You win!");
		} else {
			System.out.println("Computer Wins!");

		}
	}
	// Implement game functionality here, including a while loop and
	public static boolean isGameOver(Player player1, Player player2) {
		return player1.getHits() == 17 || player2.getHits() == 17;
	}


	public static boolean isValidInput(String input) {
		return input.isEmpty() || input.matches("\\d+");
	}

	public static void askForGuess(Scanner reader, Player guesser, Player opponent) {
		System.out.println("It's your turn.");
		System.out.println("Your guesses:");
		guesser.printMyGuesses();

		// Asks the player to guess where they think the opponent's ship is
		int row = -1;
		int col = -1;

		while (row < 0 || row > 9 || col < 0 || col > 9) {
			System.out.print("Which row? (1-10) ");
			String rowInput = reader.nextLine();
			if (rowInput.isEmpty()) {
				System.out.println("Invalid input. Please enter a number.");
				continue;
			}
			if (!isValidInput(rowInput)) {
				System.out.println("Invalid input. Please enter a number.");
				continue;
			}
			row = Integer.parseInt(rowInput) - 1;

			System.out.print("Which column? (1-10) ");
			String columnInput = reader.nextLine();
			if (columnInput.isEmpty()) {
				System.out.println("Invalid input. Please enter a number.");
				continue;
			}
			if (!isValidInput(columnInput)) {
				System.out.println("Invalid input. Please enter a number.");
				continue;
			}
			col = Integer.parseInt(columnInput) - 1;

			if (row < 0 || row > 9 || col < 0 || col > 9) {
				System.out.println("Invalid coordinates. Try again.");
			}
		}

		guesser.recordHits(opponent, row, col);
	}

	
}

